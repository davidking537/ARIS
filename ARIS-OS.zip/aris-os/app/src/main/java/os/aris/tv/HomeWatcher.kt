package os.aris.tv

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Fire TV doesn't let apps replace its home screen, so ARIS OS watches for it instead.
 * The moment Amazon's home screen comes to the front (Home button, boot, waking up),
 * ARIS OS opens on top of it. Only Amazon's launcher is watched — nothing else on the
 * TV is read.
 */
class HomeWatcher : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (event.packageName?.toString() != AMAZON_HOME) return
        if (System.currentTimeMillis() < pausedUntil(this)) return

        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
    }

    override fun onInterrupt() {}

    companion object {
        const val AMAZON_HOME = "com.amazon.tv.launcher"

        fun pausedUntil(c: Context) =
            c.getSharedPreferences("aris", Context.MODE_PRIVATE).getLong("pausedUntil", 0L)

        /** Let Amazon's home screen stay open for a while (for the Appstore, profiles, etc.). */
        fun pause(c: Context, minutes: Int) =
            c.getSharedPreferences("aris", Context.MODE_PRIVATE).edit()
                .putLong("pausedUntil", System.currentTimeMillis() + minutes * 60_000L).apply()
    }
}
