package os.aris.tv

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** The wall behind everything: a flat colour, a lamp glow, or a glow that drifts very slowly. */
class Backdrop(c: Context) : View(c) {

    private var pal = Palette.all[0]
    private var mode = 1
    private var drift = false
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val floor = Paint()
    private val m = Matrix()

    var base: Int = pal.bg
        set(v) { field = v; invalidate() }

    fun set(p: Palette, mode: Int, motion: Boolean) {
        pal = p
        this.mode = mode
        drift = mode == 2 && motion
        base = p.bg
        buildShaders()
        if (drift) start() else stop()
        invalidate()
    }

    fun resume() { if (drift) start() }
    fun pause() = stop()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = buildShaders()

    private fun buildShaders() {
        if (width == 0) return
        val r = max(width, height) * 0.7f
        val strength = if (pal.light) 0.20f else 0.17f
        glow.shader = RadialGradient(
            0f, 0f, r,
            intArrayOf(withAlpha(pal.accent, strength), withAlpha(pal.accent, strength * 0.35f), withAlpha(pal.accent, 0f)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        floor.shader = LinearGradient(
            0f, height * 0.5f, 0f, height.toFloat(),
            Color.TRANSPARENT, withAlpha(Color.BLACK, if (pal.light) 0.07f else 0.32f), Shader.TileMode.CLAMP
        )
    }

    private fun start() {
        if (anim != null) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 90_000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stop() { anim?.cancel(); anim = null }

    override fun onDraw(c: Canvas) {
        c.drawColor(base)
        if (mode == 0 || width == 0) return
        val a = (phase * 2 * PI).toFloat()
        m.setTranslate(width * (0.80f + 0.10f * cos(a)), height * (0.12f + 0.14f * sin(a)))
        glow.shader?.setLocalMatrix(m)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), glow)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), floor)
    }
}
