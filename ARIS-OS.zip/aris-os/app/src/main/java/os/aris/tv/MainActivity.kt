package os.aris.tv

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.text.format.DateFormat
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.ViewTreeObserver
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Date
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

/**
 * ARIS OS — a clean, ad-free home screen for Android TV, Google TV and Fire TV.
 */
class MainActivity : Activity() {

    data class App(val pkg: String, val label: String)
    enum class Side { RIGHT, BOTTOM }

    private lateinit var store: Store
    private var pal = Palette.all[0]

    private lateinit var root: FrameLayout
    private lateinit var backdrop: Backdrop
    private lateinit var content: LinearLayout
    private var clock: TextView? = null
    private var date: TextView? = null
    private val tracks = mutableListOf<Track>()
    private var actions: LinearLayout? = null

    private var apps: List<App> = emptyList()
    private val banners = HashMap<String, Drawable?>()
    private val icons = HashMap<String, Drawable?>()
    private val faces = HashMap<String, Typeface>()

    private var overlay: FrameLayout? = null
    private var overlaySide = Side.RIGHT
    private var overlaySize = 0
    private var panelReturn: View? = null

    private var saver: FrameLayout? = null
    private var saverClock: TextView? = null
    private var saverDate: TextView? = null
    private var hint: TextView? = null

    private var focusRow = 0
    private var focusIndex = 0
    private var moving: View? = null
    private var returningFromApp = false
    private var firstShow = true
    private var resumed = false
    private var appsLoaded = false

    private val ui = Handler(Looper.getMainLooper())
    private val emph = PathInterpolator(0.2f, 0f, 0f, 1f)
    private val fireTv by lazy {
        try { packageManager.getPackageInfo(HomeWatcher.AMAZON_HOME, 0); true } catch (_: Exception) { false }
    }

    private val motion get() = store.get(Opt.MOTION) == 0
    private fun dur(ms: Long) = if (motion) ms else ms / 3
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    private val timeTick = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = updateClock()
    }
    private val packages = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = loadApps()
    }
    private val idle = Runnable { showSaver() }
    private val saverMove = object : Runnable {
        override fun run() { moveSaver(); ui.postDelayed(this, 60_000) }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        root = FrameLayout(this).apply { clipChildren = false }
        backdrop = Backdrop(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        root.addView(backdrop, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(content, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)

        registerReceiver(packages, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        })
        render()
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        registerReceiver(timeTick, IntentFilter(Intent.ACTION_TIME_TICK))
        updateClock()
        backdrop.resume()
        if (returningFromApp || firstShow) entrance()
        returningFromApp = false
        firstShow = false
        resetIdle()
    }

    override fun onPause() {
        super.onPause()
        resumed = false
        try { unregisterReceiver(timeTick) } catch (_: Exception) {}
        backdrop.pause()
        ui.removeCallbacks(idle)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(packages) } catch (_: Exception) {}
    }

    /** Pressing Home while already home: tidy up and glide back to the first app. */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        dismissSaver()
        if (moving != null) dropMove()
        if (overlay != null) closePanel()
        focusRow = 0
        focusIndex = 0
        tracks.forEach { it.home(true) }
        tracks.firstOrNull()?.row?.getChildAt(0)?.requestFocus()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        resetIdle()
        if (saver != null) {
            if (e.action == KeyEvent.ACTION_UP) dismissSaver()
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_BACK) {
            if (e.action == KeyEvent.ACTION_UP) {
                when {
                    moving != null -> dropMove()
                    overlay != null -> closePanel()
                }
            }
            return true // this is the home screen, Back has nowhere to go
        }
        return super.dispatchKeyEvent(e)
    }

    // ---------------------------------------------------------------- apps

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val found = LinkedHashMap<String, App>()
            for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
                for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                    val p = ri.activityInfo.packageName
                    if (p == packageName || found.containsKey(p)) continue
                    found[p] = App(p, ri.loadLabel(pm).toString())
                }
            }
            val list = found.values.sortedBy { it.label.lowercase() }
            val b = HashMap<String, Drawable?>()
            val ic = HashMap<String, Drawable?>()
            for (a in list) {
                b[a.pkg] = try { pm.getApplicationBanner(a.pkg) } catch (_: Exception) { null }
                if (b[a.pkg] == null) ic[a.pkg] = try { pm.getApplicationIcon(a.pkg) } catch (_: Exception) { null }
            }
            runOnUiThread {
                apps = list
                banners.clear(); banners.putAll(b)
                icons.clear(); icons.putAll(ic)
                seedFavourites()
                render()
                if (!appsLoaded) { appsLoaded = true; entrance() }
            }
        }.start()
    }

    private fun favourites(): List<String> = store.pinned() ?: emptyList()

    /** First run: pin the popular streaming apps that are actually installed. */
    private fun seedFavourites() {
        if (store.pinned() != null || apps.isEmpty()) return
        val ids = apps.map { it.pkg }.toSet()
        val picks = listOf(
            "com.netflix.ninja", "com.google.android.youtube.tv", "com.amazon.firetv.youtube",
            "com.disney.disneyplus", "com.amazon.amazonvideo.livingroom",
            "com.amazon.avod.thirdpartyclient", "com.plexapp.android", "com.spotify.tv.android"
        ).filter { it in ids }
        store.setPinned(picks.ifEmpty { apps.take(5).map { it.pkg } })
    }

    private fun displayName(a: App) = store.label(a.pkg) ?: a.label

    private fun launch(pkg: String, from: View?) {
        val pm = packageManager
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
        if (i == null) { toast("That app can't be opened from here"); return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val opts = if (from != null && motion && from.width > 0)
            ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height).toBundle() else null
        try {
            if (motion) content.animate().alpha(0f).scaleX(0.97f).scaleY(0.97f)
                .setInterpolator(emph).setDuration(240).start()
            returningFromApp = true
            startActivity(i, opts)
        } catch (_: Exception) {
            returningFromApp = false
            content.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(150).start()
            toast("That app couldn't be opened")
        }
    }

    private fun open(i: Intent) {
        try {
            returningFromApp = true
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            returningFromApp = false
            toast("This TV doesn't support that shortcut")
        }
    }

    private fun openInputs() {
        listOf(Intent("com.android.tv.action.VIEW_INPUTS"), Intent(Settings.ACTION_SETTINGS))
            .firstOrNull { it.resolveActivity(packageManager) != null }?.let { open(it) }
            ?: toast("This TV doesn't have an inputs menu")
    }

    /** Fire TV: 5 minutes on Amazon's screen (Appstore, profiles) before ARIS takes over again. */
    private fun openAmazonHome() {
        HomeWatcher.pause(this, 5)
        open(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setPackage(HomeWatcher.AMAZON_HOME))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- type & drawables

    private fun clockFace(): Typeface = when (store.get(Opt.FONT)) {
        0 -> face("BigShouldersDisplay.ttf")
        1 -> face("YoungSerif.ttf")
        2 -> face("Fredoka.ttf")
        else -> Typeface.create("sans-serif-light", Typeface.NORMAL)
    }

    private fun face(file: String) = faces.getOrPut(file) {
        try { Typeface.createFromAsset(assets, "fonts/$file") } catch (_: Exception) { Typeface.DEFAULT }
    }

    private fun styleClock(t: TextView) {
        t.typeface = clockFace()
        t.includeFontPadding = false
        if (Build.VERSION.SDK_INT >= 26) {
            when (store.get(Opt.FONT)) {
                0 -> t.setFontVariationSettings("'wght' 600")
                2 -> t.setFontVariationSettings("'wght' 500")
            }
        }
    }

    private fun rounded(color: Int, r: Float, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
        cornerRadius = r
        setColor(color)
        if (stroke > 0) setStroke(stroke, strokeColor)
    }

    /** Focus backgrounds fade in and out instead of snapping. */
    private fun focusBg(color: Int, r: Float) = StateListDrawable().apply {
        setEnterFadeDuration(dur(160).toInt())
        setExitFadeDuration(dur(160).toInt())
        addState(intArrayOf(android.R.attr.state_focused), rounded(color, r))
        addState(intArrayOf(), rounded(Color.TRANSPARENT, r))
    }

    private fun label(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
    }

    // ---------------------------------------------------------------- home screen

    private fun render() {
        pal = Palette.all[store.get(Opt.THEME)]
        backdrop.set(pal, store.get(Opt.BACKDROP), motion)
        window.decorView.setBackgroundColor(pal.bg)
        content.removeAllViews()
        tracks.clear()
        moving = null
        hideHint()
        content.setPadding(dp(56), dp(36), dp(56), dp(28))

        val clockMode = store.get(Opt.CLOCK)
        if (clockMode != 2) {
            clock = TextView(this).apply {
                setTextColor(pal.text)
                textSize = if (clockMode == 0) 112f else 56f
                styleClock(this)
                letterSpacing = if (store.get(Opt.FONT) == 0) 0.01f else -0.02f
            }
            date = label("", if (clockMode == 0) 22f else 18f, pal.muted).apply { setPadding(dp(4), dp(6), 0, 0) }
            content.addView(clock)
            content.addView(date)
        } else {
            clock = null
            date = null
        }

        content.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        val byPkg = apps.associateBy { it.pkg }
        val twoRows = store.get(Opt.ROW2) == 1 && apps.isNotEmpty()

        if (twoRows) content.addView(rowLabel("Favourites"))
        val fav = newTrack()
        favourites().mapNotNull { byPkg[it] }.forEach { fav.row.addView(appTile(it, true)) }
        fav.row.addView(addTile(fav.row.childCount == 0))

        if (twoRows) {
            content.addView(rowLabel("All apps"))
            val all = newTrack()
            apps.forEach { all.row.addView(appTile(it, false)) }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(4), 0, 0)
        }
        val items = mutableListOf<Pair<String, () -> Unit>>()
        if (!twoRows) items += "All apps" to { openApps(false) }
        items += "Customize" to { openCustomize(0, true) }
        if (!fireTv) items += "Inputs" to { openInputs() }
        items += "Settings" to { open(Intent(Settings.ACTION_SETTINGS)) }
        if (fireTv) items += "Amazon home" to { openAmazonHome() }
        items.forEach { (text, fn) -> bar.addView(actionButton(text, fn)) }
        actions = bar
        content.addView(bar)

        updateClock()
        restoreFocus()
    }

    private fun rowLabel(text: String) = label(text, 17f, pal.muted).apply { setPadding(dp(12), dp(6), 0, 0) }

    private fun newTrack() = Track(this).apply {
        setPadding(dp(12), dp(18), dp(12), dp(20))
        duration = dur(320)
        tracks.add(this)
        content.addView(this, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
    }

    private fun restoreFocus() {
        if (overlay != null) return
        val t = tracks.getOrNull(focusRow) ?: tracks.firstOrNull() ?: return
        val v = t.row.getChildAt(focusIndex.coerceIn(0, t.row.childCount - 1)) ?: return
        v.requestFocus()
        t.reveal(v, false)
    }

    /** The one orchestrated moment: everything settles into place when you arrive home. */
    private fun entrance() {
        content.animate().cancel()
        if (!motion) {
            content.alpha = 0f; content.scaleX = 1f; content.scaleY = 1f
            content.animate().alpha(1f).setDuration(160).start()
            return
        }
        content.alpha = 0f
        content.scaleX = 1.03f
        content.scaleY = 1.03f
        content.animate().alpha(1f).scaleX(1f).scaleY(1f).setInterpolator(emph).setDuration(440).start()
        tracks.forEachIndexed { r, t ->
            for (i in 0 until min(t.row.childCount, 8)) {
                val c = t.row.getChildAt(i)
                c.translationY = dpf(18f)
                c.animate().translationY(0f).setStartDelay(60L + r * 50 + i * 30L)
                    .setInterpolator(emph).setDuration(440).start()
            }
        }
    }

    private fun updateClock() {
        val now = Date()
        val time = when (store.get(Opt.HOURS)) {
            1 -> DateFormat.format("h:mm", now).toString()
            2 -> DateFormat.format("HH:mm", now).toString()
            else -> DateFormat.getTimeFormat(this).format(now)
        }
        val day = DateFormat.format("EEEE, d MMMM", now)
        clock?.text = time
        date?.text = day
        saverClock?.text = time
        saverDate?.text = day
    }

    // ---------------------------------------------------------------- tiles

    private fun tileSize(): Pair<Int, Int> = when (store.get(Opt.TILES)) {
        0 -> dp(168) to dp(95)
        2 -> dp(256) to dp(144)
        else -> dp(208) to dp(117)
    }

    /** A focusable cell holding a card (and optionally a name under it). */
    private fun cell(w: Int, h: Int, named: Boolean): LinearLayout {
        val radius = dpf(12f)
        val card = FrameLayout(this).apply {
            background = rounded(pal.tile, radius)
            clipToOutline = true
            foreground = rounded(Color.TRANSPARENT, radius, dp(4), pal.accent).apply { alpha = 0 }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            isClickable = true
            clipChildren = false
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(w, WRAP_CONTENT).apply { marginEnd = dp(22) }
            addView(card, LinearLayout.LayoutParams(w, h))
            if (named) addView(label("", 15f, pal.text).apply {
                alpha = 0.55f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(2), dp(12), dp(2), 0)
            })
            setOnFocusChangeListener { v, has -> focusAnim(v as LinearLayout, has, h) }
        }
    }

    private fun focusAnim(cell: LinearLayout, has: Boolean, h: Int) {
        val card = cell.getChildAt(0) as FrameLayout
        val s = if (!has) 1f else if (moving === cell) 1.14f else if (motion) 1.09f else 1.04f
        card.animate().scaleX(s).scaleY(s).translationZ(if (has) dpf(16f) else 0f)
            .setInterpolator(emph).setDuration(dur(220)).start()
        card.foreground?.let { ring ->
            ValueAnimator.ofInt(ring.alpha, if (has) 255 else 0).apply {
                duration = dur(170)
                addUpdateListener { ring.alpha = it.animatedValue as Int }
                start()
            }
        }
        (cell.getChildAt(1) as? TextView)?.animate()
            ?.alpha(if (has) 1f else 0.55f)
            ?.translationY(if (has) h * (s - 1f) / 2f else 0f)
            ?.setInterpolator(emph)?.setDuration(dur(200))?.start()
        if (has) {
            val track = cell.parent?.parent as? Track ?: return
            focusRow = tracks.indexOf(track)
            focusIndex = track.row.indexOfChild(cell)
            track.reveal(cell, true)
        }
    }

    private fun fillCard(card: FrameLayout, a: App, w: Int) {
        val banner = banners[a.pkg]
        if (banner != null) {
            card.addView(ImageView(this).apply {
                setImageDrawable(banner)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        } else {
            card.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                icons[a.pkg]?.let { d ->
                    addView(ImageView(context).apply { setImageDrawable(d) }, LinearLayout.LayoutParams(w / 4, w / 4))
                }
                addView(label(displayName(a), 15f, pal.text).apply {
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(dp(12), dp(8), dp(12), 0)
                })
            }, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }
    }

    private fun appTile(a: App, favourite: Boolean): View {
        val (w, h) = tileSize()
        val named = store.get(Opt.NAMES) == 1
        val c = cell(w, h, named)
        fillCard(c.getChildAt(0) as FrameLayout, a, w)
        (c.getChildAt(1) as? TextView)?.text = displayName(a)
        c.tag = a.pkg
        c.setOnClickListener { if (moving === c) dropMove() else launch(a.pkg, c.getChildAt(0)) }
        c.setOnLongClickListener { if (moving == null) openTileMenu(a, favourite); true }
        c.setOnKeyListener { v, code, e -> tileKey(v, code, e) }
        return c
    }

    private fun addTile(empty: Boolean): View {
        val (w, h) = tileSize()
        val c = cell(w, h, store.get(Opt.NAMES) == 1)
        val card = c.getChildAt(0) as FrameLayout
        card.background = rounded(withAlpha(pal.tile, 0.4f), dpf(12f), dp(2), withAlpha(pal.muted, 0.35f))
        card.addView(label(if (empty) "Add your apps" else "Add app", 17f, pal.muted).apply {
            gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        c.setOnClickListener { openApps(true) }
        c.setOnKeyListener { v, code, e -> tileKey(v, code, e) }
        return c
    }

    private fun screenX(v: View): Float {
        val t = v.parent?.parent as? Track
        if (t != null) return t.centerOf(v)
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return loc[0] + v.width / 2f
    }

    private fun nearestAction(x: Float): View? {
        val bar = actions ?: return null
        return (0 until bar.childCount).map { bar.getChildAt(it) }.minByOrNull { abs(screenX(it) - x) }
    }

    /** All D-pad movement on the home screen is handled here so it's always predictable. */
    private fun tileKey(v: View, code: Int, e: KeyEvent): Boolean {
        if (code == KeyEvent.KEYCODE_MENU) {
            if (e.action == KeyEvent.ACTION_UP && moving == null) v.performLongClick()
            return true
        }
        if (e.action != KeyEvent.ACTION_DOWN) return false
        val t = v.parent?.parent as? Track ?: return false
        val r = tracks.indexOf(t)
        val i = t.row.indexOfChild(v)

        if (moving === v) {
            when (code) {
                KeyEvent.KEYCODE_DPAD_LEFT -> shift(t, v, -1)
                KeyEvent.KEYCODE_DPAD_RIGHT -> shift(t, v, 1)
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {}
                else -> return false
            }
            return true
        }
        when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT -> t.row.getChildAt(i - 1)?.requestFocus() ?: t.bump(1)
            KeyEvent.KEYCODE_DPAD_RIGHT -> t.row.getChildAt(i + 1)?.requestFocus() ?: t.bump(-1)
            KeyEvent.KEYCODE_DPAD_UP -> if (r > 0) tracks[r - 1].nearest(screenX(v))?.requestFocus()
            KeyEvent.KEYCODE_DPAD_DOWN ->
                if (r < tracks.lastIndex) tracks[r + 1].nearest(screenX(v))?.requestFocus()
                else nearestAction(screenX(v))?.requestFocus()
            else -> return false
        }
        return true
    }

    private fun actionButton(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTextColor(ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_focused), intArrayOf()),
            intArrayOf(pal.onAccent, pal.muted)
        ))
        background = focusBg(pal.accent, dpf(26f))
        isFocusable = true
        isClickable = true
        setPadding(dp(22), dp(10), dp(22), dp(10))
        layoutParams = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginEnd = dp(8) }
        setOnClickListener { onClick() }
        setOnKeyListener { v, code, e ->
            if (e.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            val bar = v.parent as ViewGroup
            val i = bar.indexOfChild(v)
            when (code) {
                KeyEvent.KEYCODE_DPAD_LEFT -> { bar.getChildAt(i - 1)?.requestFocus(); true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { bar.getChildAt(i + 1)?.requestFocus(); true }
                KeyEvent.KEYCODE_DPAD_UP -> { tracks.lastOrNull()?.nearest(screenX(v))?.requestFocus(); true }
                KeyEvent.KEYCODE_DPAD_DOWN -> true
                else -> false
            }
        }
    }

    // ---------------------------------------------------------------- moving tiles

    private fun startMove(c: View) {
        if (c.parent?.parent !is Track) return
        moving = c
        val card = (c as ViewGroup).getChildAt(0)
        card.animate().scaleX(1.14f).scaleY(1.14f).translationZ(dpf(28f))
            .setInterpolator(OvershootInterpolator(1.2f)).setDuration(dur(260)).start()
        showHint("Use left and right to move it. Press OK to place it.")
    }

    private fun shift(t: Track, v: View, d: Int) {
        val i = t.row.indexOfChild(v)
        val j = i + d
        val count = (0 until t.row.childCount).count { t.row.getChildAt(it).tag is String }
        if (j < 0 || j >= count) { t.bump(-d); return }
        val before = (0 until t.row.childCount).associate { t.row.getChildAt(it) to t.row.getChildAt(it).left }
        val neighbour = t.row.getChildAt(j)
        t.row.removeView(neighbour)
        t.row.addView(neighbour, i)
        // FLIP: start each tile where it was, then glide to its new slot
        t.row.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                t.row.viewTreeObserver.removeOnPreDrawListener(this)
                for ((c, left) in before) {
                    val dx = (left - c.left).toFloat()
                    if (dx != 0f) {
                        c.translationX = dx
                        c.animate().translationX(0f).setStartDelay(0)
                            .setInterpolator(emph).setDuration(dur(260)).start()
                    }
                }
                focusIndex = t.row.indexOfChild(v)
                t.reveal(v, true)
                return true
            }
        })
    }

    private fun dropMove() {
        val c = moving ?: return
        moving = null
        val row = c.parent as? LinearLayout ?: return
        store.setPinned((0 until row.childCount).mapNotNull { row.getChildAt(it).tag as? String })
        val s = if (motion) 1.09f else 1.04f
        (c as ViewGroup).getChildAt(0).animate().scaleX(s).scaleY(s).translationZ(dpf(16f))
            .setInterpolator(emph).setDuration(dur(220)).start()
        hideHint()
    }

    private fun showHint(text: String) {
        hideHint()
        val h = label(text, 17f, pal.text).apply {
            background = rounded(pal.surface, dpf(24f))
            setPadding(dp(22), dp(12), dp(22), dp(12))
            elevation = dpf(12f)
            alpha = 0f
            translationY = dpf(24f)
        }
        root.addView(h, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { bottomMargin = dp(28) })
        h.animate().alpha(1f).translationY(0f).setInterpolator(emph).setDuration(dur(260)).start()
        hint = h
    }

    private fun hideHint() {
        val h = hint ?: return
        hint = null
        h.animate().alpha(0f).translationY(dpf(24f)).setDuration(dur(180)).withEndAction { root.removeView(h) }.start()
    }

    // ---------------------------------------------------------------- panels

    private fun panelShell(side: Side) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val r = dpf(28f)
        background = GradientDrawable().apply {
            setColor(pal.surface)
            cornerRadii = if (side == Side.RIGHT) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            else floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        setPadding(dp(36), dp(32), dp(36), dp(24))
        elevation = dpf(24f)
        clipChildren = false
        clipToPadding = false
    }

    private fun panelTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 30f
        setTextColor(pal.text)
        styleClock(this)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setPadding(dp(4), 0, 0, dp(20))
    }

    private fun menuItem(text: String, enabled: Boolean = true, action: () -> Unit) =
        label(text, 19f, if (enabled) pal.text else withAlpha(pal.muted, 0.6f)).apply {
            background = focusBg(pal.tile, dpf(14f))
            setPadding(dp(20), dp(15), dp(20), dp(15))
            isFocusable = enabled
            isClickable = enabled
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(4) }
            if (enabled) setOnClickListener { action() }
        }

    private fun openPanel(panel: View, side: Side, size: Int, animate: Boolean, focus: () -> View?) {
        if (overlay == null) panelReturn = currentFocus
        overlay?.let { root.removeView(it) }

        val host = FrameLayout(this)
        val scrim = View(this).apply { setBackgroundColor(withAlpha(Color.BLACK, if (pal.light) 0.22f else 0.5f)) }
        host.addView(scrim, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        host.addView(panel,
            if (side == Side.RIGHT) FrameLayout.LayoutParams(size, MATCH_PARENT, Gravity.END)
            else FrameLayout.LayoutParams(MATCH_PARENT, size, Gravity.BOTTOM))
        root.addView(host, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        overlay = host
        overlaySide = side
        overlaySize = size
        content.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS

        if (animate) {
            scrim.alpha = 0f
            scrim.animate().alpha(1f).setDuration(dur(240)).start()
            if (side == Side.RIGHT) panel.translationX = size.toFloat() else panel.translationY = size.toFloat()
            panel.animate().translationX(0f).translationY(0f).setInterpolator(emph).setDuration(dur(360)).start()
            if (motion) content.animate().scaleX(0.97f).scaleY(0.97f).setInterpolator(emph).setDuration(360).start()
        } else {
            panel.alpha = 0f
            panel.animate().alpha(1f).setDuration(dur(140)).start()
        }
        panel.post { (focus() ?: panel.focusSearch(View.FOCUS_DOWN))?.requestFocus() }
    }

    private fun closePanel() {
        val host = overlay ?: return
        overlay = null
        host.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        val scrim = host.getChildAt(0)
        val panel = host.getChildAt(1)
        scrim.animate().alpha(0f).setDuration(dur(220)).start()
        panel.animate()
            .translationX(if (overlaySide == Side.RIGHT) overlaySize.toFloat() else 0f)
            .translationY(if (overlaySide == Side.BOTTOM) overlaySize.toFloat() else 0f)
            .setInterpolator(AccelerateInterpolator(1.5f)).setDuration(dur(240))
            .withEndAction { root.removeView(host) }.start()
        content.animate().scaleX(1f).scaleY(1f).alpha(1f).setInterpolator(emph).setDuration(dur(320)).start()
        content.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        val back = panelReturn
        panelReturn = null
        if (back != null && back.isAttachedToWindow) back.requestFocus() else restoreFocus()
    }

    // Customize ------------------------------------------------------------

    private fun openCustomize(focus: Int, animate: Boolean) {
        val panel = panelShell(Side.RIGHT)
        panel.addView(panelTitle("Customize"))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Opt.all.forEachIndexed { i, o -> list.addView(optionRow(o, i)) }
        list.addView(View(this), LinearLayout.LayoutParams(1, dp(12)))
        list.addView(menuItem("Reset favourites") {
            store.resetPinned(); seedFavourites(); render(); closePanel()
        })
        list.addView(menuItem("Done") { closePanel() })
        panel.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            isSmoothScrollingEnabled = true
            addView(list)
        }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        openPanel(panel, Side.RIGHT, dp(420), animate) { list.getChildAt(focus) }
    }

    private fun optionRow(o: Option, index: Int): View {
        val value = label("", 18f, pal.muted)
        fun show() { value.text = "‹  ${o.values[store.get(o)]}  ›" }
        show()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            background = focusBg(pal.tile, dpf(14f))
            setPadding(dp(20), dp(15), dp(16), dp(15))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(4) }
            addView(label(o.label, 19f, pal.text), LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(value)
        }
        val change = { d: Int ->
            store.step(o, d)
            show()
            value.alpha = 0.3f
            value.translationX = d * dpf(12f)
            value.animate().alpha(1f).translationX(0f).setInterpolator(emph).setDuration(dur(220)).start()
            applyOption(o, index)
        }
        row.setOnFocusChangeListener { _, has -> value.setTextColor(if (has) pal.accent else pal.muted) }
        row.setOnClickListener { change(1) }
        row.setOnKeyListener { _, code, e ->
            if (e.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            when (code) {
                KeyEvent.KEYCODE_DPAD_LEFT -> { change(-1); true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { change(1); true }
                else -> false
            }
        }
        return row
    }

    /** Every change previews live behind the panel. */
    private fun applyOption(o: Option, index: Int) {
        when (o) {
            Opt.THEME -> {
                val old = backdrop.base
                render()
                val new = pal.bg
                ValueAnimator.ofObject(ArgbEvaluator(), old, new).apply {
                    duration = dur(420)
                    addUpdateListener { backdrop.base = it.animatedValue as Int }
                    start()
                }
                content.alpha = 0f
                content.animate().alpha(1f).setDuration(dur(320)).start()
                openCustomize(index, false) // repaint the panel in the new colours
            }
            Opt.MOTION, Opt.FONT -> { render(); openCustomize(index, false) }
            Opt.SAVER -> resetIdle()
            else -> render()
        }
    }

    // Tile menu ------------------------------------------------------------

    private fun openTileMenu(a: App, favourite: Boolean) {
        val panel = panelShell(Side.RIGHT)
        panel.addView(panelTitle(displayName(a)))
        val pinned = favourites()
        if (favourite) {
            panel.addView(menuItem("Move") {
                val c = panelReturn
                closePanel()
                c?.let { ui.post { startMove(it) } }
            })
            panel.addView(menuItem("Remove from favourites") {
                store.setPinned(pinned - a.pkg)
                focusIndex = (focusIndex - 1).coerceAtLeast(0)
                closePanel(); render()
            })
        } else if (a.pkg in pinned) {
            panel.addView(menuItem("Already in favourites", enabled = false) {})
        } else {
            panel.addView(menuItem("Add to favourites") { store.setPinned(pinned + a.pkg); closePanel(); render() })
        }
        panel.addView(menuItem("Rename") { openRename(a) })
        if (store.label(a.pkg) != null) {
            panel.addView(menuItem("Use original name") { store.clearLabel(a.pkg); closePanel(); render() })
        }
        panel.addView(menuItem("App info") {
            closePanel()
            open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
        })
        openPanel(panel, Side.RIGHT, dp(380), true) { null }
    }

    private fun openRename(a: App) {
        val panel = panelShell(Side.RIGHT)
        panel.addView(panelTitle("Rename"))
        val field = EditText(this).apply {
            setText(displayName(a))
            setSelectAllOnFocus(true)
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_DONE
            textSize = 21f
            setTextColor(pal.text)
            setHintTextColor(pal.muted)
            hint = a.label
            background = rounded(pal.tile, dpf(14f), dp(2), pal.accent)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        val save = {
            val t = field.text.toString().trim()
            if (t.isEmpty() || t == a.label) store.clearLabel(a.pkg) else store.setLabel(a.pkg, t)
            closePanel()
            render()
        }
        field.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_DONE) { save(); true } else false
        }
        panel.addView(field, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(16) })
        panel.addView(menuItem("Save name") { save() })
        openPanel(panel, Side.RIGHT, dp(420), false) { field }
    }

    // All apps sheet ---------------------------------------------------------

    private fun openApps(pick: Boolean) {
        val panel = panelShell(Side.BOTTOM)
        panel.addView(panelTitle(if (pick) "Add to favourites" else "All apps"))
        val cols = 5
        val gap = dp(18)
        val avail = root.width - dp(72) - dp(24)
        val w = (avail - gap * (cols - 1)) / cols
        val h = w * 9 / 16
        val grid = GridLayout(this).apply {
            columnCount = cols
            clipChildren = false
            clipToPadding = false
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }
        val pinned = favourites().toMutableList()
        apps.forEach { a ->
            val c = cell(w, h, true)
            c.layoutParams = GridLayout.LayoutParams().apply {
                width = w
                setMargins(0, 0, gap, gap)
            }
            val card = c.getChildAt(0) as FrameLayout
            fillCard(card, a, w)
            (c.getChildAt(1) as TextView).text = displayName(a)
            if (pick) {
                val badge = label("✓", 16f, pal.onAccent).apply {
                    gravity = Gravity.CENTER
                    background = rounded(pal.accent, dpf(14f))
                    elevation = dpf(4f)
                    val on = a.pkg in pinned
                    scaleX = if (on) 1f else 0f
                    scaleY = if (on) 1f else 0f
                }
                card.addView(badge, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END)
                    .apply { setMargins(0, dp(8), dp(8), 0) })
                c.setOnClickListener {
                    val on = a.pkg !in pinned
                    if (on) pinned.add(a.pkg) else pinned.remove(a.pkg)
                    store.setPinned(pinned)
                    badge.animate().scaleX(if (on) 1f else 0f).scaleY(if (on) 1f else 0f)
                        .setInterpolator(if (on) OvershootInterpolator(2f) else emph)
                        .setDuration(dur(240)).start()
                    render()
                }
            } else {
                c.setOnClickListener {
                    closePanel()
                    launch(a.pkg, card)
                }
            }
            grid.addView(c)
        }
        panel.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            isSmoothScrollingEnabled = true
            clipChildren = false
            addView(grid)
        }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        openPanel(panel, Side.BOTTOM, root.height - dp(56), true) { grid.getChildAt(0) }
    }

    // ---------------------------------------------------------------- screensaver

    private fun resetIdle() {
        ui.removeCallbacks(idle)
        val minutes = when (store.get(Opt.SAVER)) { 1 -> 5; 2 -> 15; else -> 0 }
        if (minutes > 0 && resumed && saver == null) ui.postDelayed(idle, minutes * 60_000L)
    }

    private fun showSaver() {
        if (saver != null || overlay != null || !resumed) return
        val s = FrameLayout(this).apply {
            setBackgroundColor(if (pal.light) Color.parseColor("#10151C") else pal.bg)
            alpha = 0f
        }
        val big = TextView(this).apply {
            setTextColor(if (pal.light) Color.parseColor("#E4E8EC") else pal.text)
            textSize = 120f
            styleClock(this)
        }
        val d = label("", 22f, pal.muted).apply { setPadding(dp(4), dp(8), 0, 0) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(big)
            addView(d)
        }
        s.addView(box, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        root.addView(s, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        saver = s
        saverClock = big
        saverDate = d
        updateClock()
        s.animate().alpha(1f).setDuration(1400).start()
        box.post { placeSaver(box) }
        ui.postDelayed(saverMove, 60_000)
    }

    /** Drift the clock to a new spot each minute so nothing burns into the screen. */
    private fun moveSaver() {
        val box = (saver?.getChildAt(0)) ?: return
        box.animate().alpha(0f).setDuration(900).withEndAction {
            placeSaver(box)
            box.animate().alpha(1f).setDuration(900).start()
        }.start()
    }

    private fun placeSaver(box: View) {
        val s = saver ?: return
        box.translationX = Random.nextInt(dp(40), (s.width - box.width - dp(40)).coerceAtLeast(dp(41))).toFloat()
        box.translationY = Random.nextInt(dp(40), (s.height - box.height - dp(40)).coerceAtLeast(dp(41))).toFloat()
    }

    private fun dismissSaver() {
        val s = saver ?: return
        saver = null
        saverClock = null
        saverDate = null
        ui.removeCallbacks(saverMove)
        s.animate().alpha(0f).setDuration(300).withEndAction { root.removeView(s) }.start()
        resetIdle()
    }
}
