package os.aris.tv

import android.animation.TimeInterpolator
import android.content.Context
import android.view.View
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.min

/**
 * A row of tiles that glides instead of jumping. Children are laid out at full width
 * and the row slides with an eased translation whenever focus nears an edge.
 */
class Track(c: Context) : FrameLayout(c) {

    val row = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        clipChildren = false
        clipToPadding = false
    }
    var duration = 320L
    var interp: TimeInterpolator = PathInterpolator(0.2f, 0f, 0f, 1f)

    private var pending: View? = null
    private var target = 0f
    private val edge get() = resources.displayMetrics.density * 64

    init {
        clipChildren = false
        clipToPadding = false
        addView(row)
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val free = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        row.measure(free, free)
        setMeasuredDimension(MeasureSpec.getSize(widthSpec), row.measuredHeight + paddingTop + paddingBottom)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        row.layout(paddingLeft, paddingTop, paddingLeft + row.measuredWidth, paddingTop + row.measuredHeight)
        pending?.let { pending = null; reveal(it, false) }
    }

    /** Slide the row just enough to keep [child] comfortably on screen. */
    fun reveal(child: View, animate: Boolean) {
        if (width == 0 || child.width == 0) { pending = child; return }
        val view = (width - paddingLeft - paddingRight).toFloat()
        var t = target
        val l = child.left + t
        val r = child.right + t
        if (r > view - edge) t -= r - (view - edge)
        if (l < edge) t += edge - l
        t = min(t, 0f)
        target = t
        if (animate) {
            row.animate().translationX(t).setInterpolator(interp).setDuration(duration).start()
        } else {
            row.animate().cancel()
            row.translationX = t
        }
    }

    fun home(animate: Boolean) {
        target = 0f
        if (animate) row.animate().translationX(0f).setInterpolator(interp).setDuration(duration).start()
        else row.translationX = 0f
    }

    /** Where a child will sit on screen once the row stops moving. */
    fun centerOf(child: View): Float {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        return loc[0] + paddingLeft + child.left + target + child.width / 2f
    }

    fun nearest(x: Float): View? =
        (0 until row.childCount).map { row.getChildAt(it) }.minByOrNull { abs(centerOf(it) - x) }

    /** A small nudge when you hit the end of the row. */
    fun bump(direction: Int) {
        val d = direction * resources.displayMetrics.density * 10
        animate().translationX(d).setDuration(90).withEndAction {
            animate().translationX(0f).setInterpolator(interp).setDuration(220).start()
        }.start()
    }
}
