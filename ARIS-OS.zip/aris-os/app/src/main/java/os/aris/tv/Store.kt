package os.aris.tv

import android.content.Context

class Option(val key: String, val label: String, val values: List<String>, val default: Int)

object Opt {
    val THEME = Option("theme", "Theme", Palette.all.map { it.name }, 0)
    val BACKDROP = Option("backdrop", "Background", listOf("Plain", "Glow", "Drifting glow"), 1)
    val FONT = Option("font", "Clock font", listOf("Condensed", "Serif", "Rounded", "Classic"), 0)
    val CLOCK = Option("clock", "Clock size", listOf("Large", "Small", "Hidden"), 0)
    val HOURS = Option("hours", "Time format", listOf("Match TV", "12-hour", "24-hour"), 0)
    val TILES = Option("tiles", "Tile size", listOf("Small", "Medium", "Large"), 1)
    val NAMES = Option("names", "App names", listOf("Hidden", "Shown"), 0)
    val ROW2 = Option("row2", "Second row", listOf("Off", "All apps"), 1)
    val MOTION = Option("motion", "Animations", listOf("Full", "Reduced"), 0)
    val SAVER = Option("saver", "Clock screensaver", listOf("Off", "After 5 min", "After 15 min"), 0)
    val all = listOf(THEME, BACKDROP, FONT, CLOCK, HOURS, TILES, NAMES, ROW2, MOTION, SAVER)
}

class Store(c: Context) {
    private val p = c.getSharedPreferences("aris", Context.MODE_PRIVATE)

    fun get(o: Option) = p.getInt(o.key, o.default).coerceIn(0, o.values.lastIndex)

    fun step(o: Option, d: Int) {
        val n = o.values.size
        p.edit().putInt(o.key, ((get(o) + d) % n + n) % n).apply()
    }

    fun pinned(): List<String>? =
        p.getString("pinned", null)?.split(",")?.filter { it.isNotBlank() }

    fun setPinned(list: List<String>) =
        p.edit().putString("pinned", list.distinct().joinToString(",")).apply()

    fun resetPinned() = p.edit().remove("pinned").apply()

    fun label(pkg: String): String? = p.getString("name:$pkg", null)
    fun setLabel(pkg: String, name: String) = p.edit().putString("name:$pkg", name).apply()
    fun clearLabel(pkg: String) = p.edit().remove("name:$pkg").apply()
}
