package os.aris.tv

import android.graphics.Color

/** Each theme is a room at a different time of day: wall, panel, tile, ink, muted ink, one lamp. */
data class Palette(
    val name: String,
    val bg: Int,
    val surface: Int,
    val tile: Int,
    val text: Int,
    val muted: Int,
    val accent: Int,
    val onAccent: Int,
    val light: Boolean = false
) {
    companion object {
        private fun c(s: String) = Color.parseColor(s)
        val all = listOf(
            Palette("Dusk", c("#0E2730"), c("#133240"), c("#1A4250"), c("#EEF1EA"), c("#8FB0B0"), c("#F4B740"), c("#0E2730")),
            Palette("Ember", c("#2A1420"), c("#351B2A"), c("#45243A"), c("#F6E9E1"), c("#C29A9E"), c("#F2A65A"), c("#2A1420")),
            Palette("Fjord", c("#12202E"), c("#172A3C"), c("#213A52"), c("#E8F1F7"), c("#8BA7BD"), c("#9FE3F2"), c("#10202C")),
            Palette("Moss", c("#17231A"), c("#1D2C21"), c("#29402E"), c("#ECEFE2"), c("#A3B395"), c("#D9C26A"), c("#17231A")),
            Palette("Daylight", c("#E4E8EC"), c("#F4F6F8"), c("#FFFFFF"), c("#1B2430"), c("#5E6B7A"), c("#2F5BEA"), c("#FFFFFF"), true)
        )
    }
}

fun withAlpha(c: Int, a: Float) = Color.argb((a * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))
