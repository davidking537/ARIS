# ARIS OS

A clean home screen for your TVs: a big clock, the apps you choose, and three
shortcuts (All apps, Inputs, Settings). No ads, no recommendation rows, nothing
running in the background.

## Which TVs it runs on

| TV / device | How ARIS OS gets on it |
|---|---|
| Android TV / Google TV (Sony, TCL, Hisense, Philips, Chromecast, onn) | Installs directly and replaces the home screen |
| Fire TV | Installs directly; Amazon keeps the Home button, so open ARIS from Your Apps or remap Home |
| Samsung, LG, Roku | Their systems are locked. Plug in a Google TV stick (Google TV Streamer, Chromecast with Google TV, onn 4K) and run ARIS OS on that |

## 1. Get the app (no Android Studio needed)

1. Create a new repo on GitHub and upload this whole folder.
2. Open the **Actions** tab. The "Build ARIS OS" job runs on its own.
3. When it finishes, download **ARIS-OS-apk** from the job page and unzip it.

## 2. Turn on debugging on the TV

Settings → System → About → click **Android TV OS build** 7 times.
Then Settings → System → Developer options → turn on **USB debugging** / **Network debugging**.
Fire TV: Settings → My Fire TV → Developer options → **ADB debugging** on.

Note the TV's IP address (Settings → Network).

## 3. Install and clean up

You need `adb` on your computer (Android "platform-tools"). On Windows, run the script in Git Bash.

```
./scripts/aris-tool.sh 192.168.1.50 install app-debug.apk
./scripts/aris-tool.sh 192.168.1.50 google     # or: fire
./scripts/aris-tool.sh 192.168.1.50 speed
```

Accept the "Allow debugging?" prompt on the TV the first time.

Brand extras (Sony, TCL, Hisense) differ by model, so they're not removed
automatically. Run `scan`, pick what you don't want, then `disable <package>`.

**Undo everything:** `./scripts/aris-tool.sh 192.168.1.50 restore`

## Using ARIS OS

- Select a tile to open the app. It grows out of its tile as it opens.
- Hold OK (or press Menu) on a tile to move, rename, remove or add it to favourites.
- **Move** lifts the tile: slide it with left and right, press OK to drop it.
- **Add app** opens every installed app. Tick the ones you want in favourites.
- Pressing Home always glides back to the first tile.

## Customize

Open **Customize** from the bottom bar. Use left and right to change a setting; everything previews live.

- **Theme:** Dusk, Ember, Fjord, Moss, Daylight
- **Background:** plain, a soft lamp glow, or a glow that drifts very slowly
- **Clock font:** Condensed, Serif, Rounded, Classic
- **Clock size:** large, small, or hidden
- **Time format:** match the TV, 12-hour, 24-hour
- **Tile size:** small, medium, large
- **App names:** shown or hidden under tiles
- **Second row:** an "All apps" row under your favourites
- **Animations:** full, or reduced for older sticks
- **Clock screensaver:** a drifting clock after 5 or 15 minutes
