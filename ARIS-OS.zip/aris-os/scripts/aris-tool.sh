#!/usr/bin/env bash
# ARIS OS tool — install, debloat and speed up a TV over the network.
# Everything here is reversible with: ./aris-tool.sh <TV_IP> restore
#
#   ./aris-tool.sh <TV_IP> install <ARIS.apk>   install ARIS OS
#   ./aris-tool.sh <TV_IP> speed                 faster animations (feels snappier)
#   ./aris-tool.sh <TV_IP> google                debloat Android TV / Google TV + make ARIS the home screen
#   ./aris-tool.sh <TV_IP> fire                  debloat Fire TV (what Amazon still allows)
#   ./aris-tool.sh <TV_IP> scan                  list brand extras (Sony/TCL/Hisense…) for you to review
#   ./aris-tool.sh <TV_IP> disable <package>     disable one package you picked from scan
#   ./aris-tool.sh <TV_IP> restore               undo everything this script did

set -u
IP="${1:?TV IP address needed}"; MODE="${2:?mode needed}"
DEV="$IP:5555"
LOG="aris-disabled-$IP.txt"

adb connect "$DEV" >/dev/null || { echo "Couldn't reach $DEV. Turn on network/USB debugging on the TV."; exit 1; }
A=(adb -s "$DEV")
PKGS="$("${A[@]}" shell pm list packages | tr -d '\r' | sed 's/^package://')"
has() { grep -qx "$1" <<<"$PKGS"; }

disable() {
  for p in "$@"; do
    if has "$p"; then
      if "${A[@]}" shell pm disable-user --user 0 "$p" >/dev/null 2>&1; then
        echo "$p" >> "$LOG"; echo "  disabled  $p"
      else
        echo "  blocked   $p (the TV won't allow this one)"
      fi
    fi
  done
}

# Safe extras: removing these doesn't break playback, inputs or the remote.
GOOGLE_EXTRAS=(
  com.google.android.tvrecommendations
  com.google.android.feedback
  com.google.android.play.games
  com.google.android.videos
  com.google.android.youtube.tvmusic
)
# Stock home screens. Only disabled once ARIS OS is installed, so the TV always has a home.
GOOGLE_HOMES=(
  com.google.android.apps.tv.launcherx
  com.google.android.tvlauncher
)
FIRE_EXTRAS=(
  com.amazon.device.crashmanager
)

case "$MODE" in
  install)
    APK="${3:?path to the ARIS OS apk needed}"
    "${A[@]}" install -r "$APK" && echo "ARIS OS installed. Next: ./aris-tool.sh $IP google (or fire)";;
  speed)
    for k in window_animation_scale transition_animation_scale animator_duration_scale; do
      "${A[@]}" shell settings put global "$k" 0.5
    done
    echo "Animations set to 0.5x.";;
  google)
    disable "${GOOGLE_EXTRAS[@]}"
    if has os.aris.tv; then
      disable "${GOOGLE_HOMES[@]}"
      "${A[@]}" shell am start -n os.aris.tv/.MainActivity >/dev/null
      echo "ARIS OS is now the home screen. Press Home on the remote to check."
    else
      echo "ARIS OS isn't installed yet, so the stock home screen was left alone."
    fi;;
  fire)
    disable "${FIRE_EXTRAS[@]}"
    if has os.aris.tv; then
      SVC="os.aris.tv/os.aris.tv.HomeWatcher"
      CUR="$("${A[@]}" shell settings get secure enabled_accessibility_services | tr -d '\r')"
      [[ "$CUR" == "null" || -z "$CUR" ]] && NEW="$SVC" || NEW="$CUR:$SVC"
      [[ "$CUR" == *"$SVC"* ]] || "${A[@]}" shell settings put secure enabled_accessibility_services "$NEW"
      "${A[@]}" shell settings put secure accessibility_enabled 1
      "${A[@]}" shell am start -n os.aris.tv/.MainActivity >/dev/null
      echo "ARIS OS now takes over the Home button. Press Home on the remote to check."
    else
      echo "Install ARIS OS first: ./aris-tool.sh $IP install app-debug.apk"
    fi;;
  scan)
    echo "Brand and ad-related packages on this TV (review before disabling):"
    grep -iE 'recommend|promo|advert|ads|analytics|feedback|tcl|hisense|sony|philips|amazon' <<<"$PKGS" | sort;;
  disable)
    disable "${3:?package name needed}";;
  restore)
    if [[ -f "$LOG" ]]; then
      sort -u "$LOG" | while read -r p; do
        "${A[@]}" shell pm enable "$p" >/dev/null 2>&1 && echo "  enabled   $p"
      done
      rm "$LOG"
    fi
    for k in window_animation_scale transition_animation_scale animator_duration_scale; do
      "${A[@]}" shell settings put global "$k" 1
    done
    CUR="$("${A[@]}" shell settings get secure enabled_accessibility_services | tr -d '\r')"
    NEW="$(tr ':' '\n' <<<"$CUR" | grep -v '^os.aris.tv/' | paste -sd: -)"
    "${A[@]}" shell settings put secure enabled_accessibility_services "${NEW:-null}"
    echo "Restored.";;
  *) echo "Unknown mode: $MODE"; exit 1;;
esac
